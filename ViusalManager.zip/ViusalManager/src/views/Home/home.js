import React, { Component } from 'react';
import Documents from '../Components/Documents';
import UserList  from '../Components/Userlist';
import ModalPopUp  from '../Components/modal';
import {Button} from 'reactstrap';
import {  Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';
import ApiUrl from '../../enviorment';
import Cookies from 'universal-cookie';
import axios from 'axios';
const cookies = new Cookies();


class Home extends Component {
  constructor(props) {
    super(props);
    this.state={
      danger: false,
      modaltitle:'Add Project',
      projectName:"",
      Object:'',
      data:[{}]

    }
  }
  componentWillMount() {
     axios.get(ApiUrl+'project/?user_id='+cookies.get('user_id'))
      .then(res => {
        console.log("==",res.data)
        this.setState({ data: res.data.project})
         
        
      })
  }
  changeSelectionRecords(e){
    this.setState({Object: e.data})
    cookies.set('project_id',this.state.Object.id)
   // this.props.history.push('/dashboard');
  }
  editUser(e){
  this.setState({ Object: e }, () => {
   
  //  alert(this.state.selectedCar1["name"])
  //  console.log(this.state.projectName)
  // this.setState({projectName: this.state.selectedCar1["name"]})
   this.setState({danger: !this.state.danger});
   
   }); 
  //alert(this.state.selectedCar1["name"])
  
     
    console.log("object",this.state.Object)
    
  }
  deleteUser(){
    alert('');
  }
  handleUserInput = (e) => {
    
    this.setState({projectName:e.target.value})
  }
  
  changeHandler(event,stateName) {
    this.setState({ yourName: event.target.value }, () => 
    console.log(this.state.yourName));
  }
   toggleDanger() {
    //alert('')
    this.setState({Object:""})
    this.setState({danger: !this.state.danger});
  }
  saveProject(){
    
     axios.post(ApiUrl+'project/?user_id='+cookies.get('user_id'),{'projectName':this.state.projectName})
      .then(res => {
         this.setState({succss:"true"})
         this.setState({ data: res.data.project})
        //this.props.history.push('/home');
      })
      this.toggleDanger()
      this.componentWillMount()
  }
  redirecToDashboard(){
       this.props.history.push('/dashboard');
  }
  render() {
    return (
      <div className="animated fadeIn">
       <ModalPopUp modaltitle={this.state.modaltitle} buttonName='Add Project' danger={this.state.danger} saveButton={this.saveProject.bind(this)} toggleDanger={this.toggleDanger.bind(this)}>
         <Input type="text" placeholder="project Name" value={this.state.Object.name}  onChange={this.handleUserInput.bind(this)}  autoComplete="projectName" />
         
       </ModalPopUp>
        <br></br>
       <UserList redirecToDashboard={this.redirecToDashboard.bind(this)} data={this.state.data} editUser={this.editUser.bind(this,this.state.data)} actionTemplate={this.actionTemplate} selectedCar1={this.state.Object} changeSelection={this.changeSelectionRecords.bind(this)}/>
       
        </div>
   );
  }
}

export default Home;

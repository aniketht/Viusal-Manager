import React from 'react';

const Documents = (props) => {
    return (
        <div>
            <h1>m in child</h1>
        </div>
    )
}
export default Documents;
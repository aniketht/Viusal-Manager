import React,{ Component } from 'react';
import {DataTable} from 'primereact/datatable';
import {Column} from 'primereact/column';

class UserList extends Component {
  constructor(props) {
    super(props);
    this.state={
    	selectedObject:""
    }
   }
   actionTemplate() {
        return <div>
            <i className="fa fa-edit" onClick={this.props.editUser}></i>&nbsp; 
            <i className="fa fa-link" onClick={this.props.redirecToDashboard}></i> 
            

        </div>;
    }
    componentWillReceiveProps(PropsData){
      console.log("==nextprops")
      
    }
    
    
    render() {
    return (
        <div>
           <DataTable value={this.props.data} paginator={true} selectionMode="single" selection={this.props.selectedCar1} responsive={true} onSelectionChange={this.props.changeSelection} rows={10} rowsPerPageOptions={[5,10,20]}>
                
                <Column field="name" style={{color:'blue'}}  header="Name" sortable={true} filter={true} />
                <Column field="created_on" header="Created Date" sortable={true} filter={true} />
                <Column header="Action" body={this.actionTemplate.bind(this)} style={{textAlign:'center', width: '6em'}}/>

            </DataTable>

        </div>
    )
   }
}
export default UserList;


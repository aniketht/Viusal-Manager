import React, { Component } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import {FileUpload} from 'primereact/fileupload';
import {Lightbox} from 'primereact/lightbox';

import {
  Badge,
  Button,
  ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  CardTitle,
  Col,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Progress,
  Row,
  Table,
} from 'reactstrap';
var images=[
    {source:'/assets/img/image1.jpeg', thumbnail:'/assets/img/image1.jpeg', title:'Sopranos 1'},
    {source:'/assets/img/images2.jpeg', thumbnail:'/assets/img/images2.jpeg', title:'Sopranos 2'},
    {source:'/assets/img/images3.jpeg', thumbnail:'/assets/img/images3.jpeg', title:'Sopranos 3'},
     {source:'/assets/img/image1.jpeg', thumbnail:'/assets/img/image1.jpeg', title:'Sopranos 1'},
    {source:'/assets/img/images2.jpeg', thumbnail:'/assets/img/images2.jpeg', title:'Sopranos 2'},
    {source:'/assets/img/images3.jpeg', thumbnail:'/assets/img/images3.jpeg', title:'Sopranos 3'},
     {source:'/assets/img/image1.jpeg', thumbnail:'/assets/img/image1.jpeg', title:'Sopranos 1'},
    {source:'/assets/img/images2.jpeg', thumbnail:'/assets/img/images2.jpeg', title:'Sopranos 2'},
   
    
];

class Dashboard extends Component {
  constructor(props) {
    super(props);

    
    
  }

  
  render() {

    return (
      <div className="animated fadeIn">
       <FileUpload name="demo[]" url="http://localhost:8000/api/Images/" multiple={true}   />
       <br></br>
       <Lightbox width="560" height="315" type="images" images={images}  />

     
      </div>
    );
  }
}

export default Dashboard;

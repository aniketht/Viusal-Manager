
import React, { Component } from 'react';
import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';
import { GoogleLogin } from 'react-google-login';
import ApiUrl from '../../../enviorment';
import axios from 'axios';
import Cookies from 'universal-cookie';
const cookies = new Cookies();

const responseGoogle = (response) => {
  console.log(response);
}
class Login extends Component {

   constructor (props) {
    super(props);
    this.state = {visible: false};
    this.state = {
      username: '',
      password: '',
      formErrors: {username: '', password: ''},
      usernameValid: false,
      passwordValid: false,
      formValid: false,
      succss:false,
      forgotEmail:''
    }
  }

  handleUserInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({[name]: value},
                  () => { this.validateField(name, value) });
  }

  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let usernameValid = this.state.usernameValid;
    let passwordValid = this.state.passwordValid;

    switch(fieldName) {
      case 'username':
        usernameValid = value.length >0;
        fieldValidationErrors.username = usernameValid ? '' : 'Please enter the username';
        break;
      case 'password':
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? '': 'Password should atleast 6 char long';
        break;
      default:
        break;
    }
    this.setState({formErrors: fieldValidationErrors,
                    usernameValid: usernameValid,
                    passwordValid: passwordValid
                  }, this.validateForm);
  }
  authUser()
  {
    axios.post(ApiUrl+'login/',{'username':this.state.username,'password':this.state.password})
      .then(res => {
         
         cookies.set('user_id',res.data.id);
         cookies.set('authToken',res.data.token)
         console.log(cookies)
         this.setState({succss:"true"})
        this.props.history.push('/home');
      })
  }

  validateForm() {
    this.setState({formValid: this.state.usernameValid && this.state.passwordValid});
  }

  errorClass(error) {
    return(error.length === 0 ? '' : 'has-error');
  }
  render() {
    return (
      <div className="app flex-row align-items-center">
        <Container>
          <Row className="justify-content-center">
            <Col md="5">
              <CardGroup>
                <Card className="p-4">
                  <CardBody>
                    <Form>
                      <h1>Login</h1>
                      <p className="text-muted">Sign In to your account</p>
                      <InputGroup className="mb-3">
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText>
                            <i className="icon-user"></i>
                          </InputGroupText>
                        </InputGroupAddon>
                        <Input type="text" placeholder="Username"  name="username" value={this.state.username} onChange={this.handleUserInput}  autoComplete="username" />
                        </InputGroup>
                        <p className="onerror Remember">{this.state.formErrors.username}</p>
                      <InputGroup className="mb-4">
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText>
                            <i className="icon-lock"></i>
                          </InputGroupText>
                        </InputGroupAddon>
                        <Input type="password" placeholder="Password" name="password" value={this.state.password}  onChange={this.handleUserInput} autoComplete="current-password" />
                      </InputGroup>
                      <p className="onerror Remember"> {this.state.formErrors.password}</p>
                      <Row>
                        <Col xs="6">
                          <Button color="primary" className="px-4" onClick={((e) => this.authUser())} disabled={!this.state.formValid}>Login</Button>
                        </Col>
                        
                       
                      </Row>
                     <br></br>
                     <Row>
                     <Col xs="8">
                     <GoogleLogin
                         clientId="271610294187-epbvjasqc5rn2kpl597eeui8g03gh0jr.apps.googleusercontent.com"
                         buttonText="Sign With Google"
                         onSuccess={responseGoogle}
                         onFailure={responseGoogle}
                        />
                     </Col>
                     </Row>
                    </Form>
                  </CardBody>
                </Card>
                
              </CardGroup>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Login;
